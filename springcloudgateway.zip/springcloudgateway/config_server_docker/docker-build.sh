#! /bin/bash

docker build -t dev_config_server .
